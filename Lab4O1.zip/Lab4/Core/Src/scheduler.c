/*
 * scheduler.c
 *
 *  Created on: Nov 21, 2021
 *      Author: khanh
 */
#include "tasks.h"
#include "main.h"
#include "scheduler.h"

typedef struct
{
	// Pointer to the task.
	void (*pTask)(void);
	// Delay (ticks) until the function will next be run.
	uint32_t Delay;
	// Interval (ticks) between subsequent runs.
	uint32_t Period;
	// Incremented (by scheduler) when task is due to execute.
	uint8_t RunMe;
} sTask;

// MUST BE ADJUSTED FOR EACH NEW PROJECT
#define SCH_MAX_TASKS 5
#define NO_TASK_ID 0
sTask SCH_tasks_G[SCH_MAX_TASKS];


void SCH_Init(void)
{
	unsigned char i;
	for (i = 0; i < SCH_MAX_TASKS; i++)
	{
		SCH_Delete_Task(i);
	}
	// Reset the global error variable.
	// SCH_Delete_Task will generate an error code
	// because the array is empty.
	//Error_code_G = 0;
	//Timer_init();
	//Watchdog_init();
}



void SCH_Update(void)
{
	// Check if there is a task at this location.
	int Index = 0;
	if (SCH_tasks_G[Index].pTask)
	{
		//SCH_tasks_G[Index].Delay -= 1;
		if (SCH_tasks_G[Index].Delay <= 0)
		{
			// The task is due to run.
			// Increment the RunMe flag.
			SCH_tasks_G[Index].RunMe += 1;
		}
		else
		{
			// Not yet ready to run; just increment the delay.
			SCH_tasks_G[Index].Delay -= 1;
		}
	}
}

unsigned char SCH_Add_Task(void (*pFunction)(), unsigned int DELAY, unsigned int PERIOD)
{
	unsigned char lastFreeIndex = 0;
	// First find a gap in the array (if any).
	while ((SCH_tasks_G[lastFreeIndex].pTask != 0) && (lastFreeIndex < SCH_MAX_TASKS))
	{
		lastFreeIndex++;
	}
	// Have we reached the end of the list?
	if (lastFreeIndex == SCH_MAX_TASKS)
	{
		// Task list is full.
		// Set the global error variable.
		// Error_code_G = ERROR_SCH_TOO_MANY_TASKS;
		// Also return an error code.
		return SCH_MAX_TASKS;
	}
	// If we are here, there is at least a free space in the task array.
	// If the task is empty then just add it to the head of the array.
	if (lastFreeIndex == 0)
	{
		SCH_tasks_G[0].pTask = pFunction;
		SCH_tasks_G[0].Delay = DELAY;
		SCH_tasks_G[0].Period = PERIOD;
		SCH_tasks_G[0].RunMe = 0;
		return 0;
	}
	else
	{
		// If not then we start comparing the new delay
		// with others in the array.
		uint32_t taskDelay = DELAY;
		int suitableIndex;
		for (suitableIndex = 0; suitableIndex <= lastFreeIndex; suitableIndex++)
		{
			// If the new delay is greater than that of the
			// current task at this index, then the new task
			// is bound to be executed later than the task
			// at this index. In other words, the new task
			// should be placed at an index greater than the
			// current index.
			if (taskDelay >= SCH_tasks_G[suitableIndex].Delay && SCH_tasks_G[suitableIndex].pTask != 0)
			{
				taskDelay -= SCH_tasks_G[suitableIndex].Delay;
			}
			// If the new delay is less that that of the
			// current task at this index then we insert
			// the new task here and shift right all the
			// other tasks that have a greater delay.
			else
			{
				if (SCH_tasks_G[suitableIndex].pTask != 0 && taskDelay)
					SCH_tasks_G[suitableIndex].Delay -= taskDelay;
				break;
			}
		}
		// Shift right from the index after the suitable
		// index.
		for (int i = lastFreeIndex; i > suitableIndex; i--)
		{
			SCH_tasks_G[i] = SCH_tasks_G[i-1];
		}
		// Modify the content at the suitable index to
		// that of new task.
		SCH_tasks_G[suitableIndex].pTask = pFunction;
		SCH_tasks_G[suitableIndex].Delay = taskDelay;
		SCH_tasks_G[suitableIndex].Period = PERIOD;
		SCH_tasks_G[suitableIndex].RunMe = 0;
		return suitableIndex;
	}
	//insertionSort(SCH_tasks_G);
	// Return position of task (to allow later deletion).
}

void SCH_Dispatch_Tasks(void)
{
	unsigned char Index = 0;
	//Dispatches (runs) the next task (if there is one ready).
	for (Index = 0; Index < SCH_MAX_TASKS; Index++)
	{
		if (SCH_tasks_G[Index].RunMe > 0)
		{
			(*SCH_tasks_G[Index].pTask)();
			SCH_tasks_G[Index].RunMe -= 1; // Reset / reduce RunMe flag.
			// With our new implementation, we cannot simply rely
			// on automatic renewal of periodic tasks. We need
			// to delete them and add a new one.
			sTask temp = SCH_tasks_G[Index];
			SCH_Delete_Task(Index);
			if (temp.Period > 0)
			SCH_Add_Task(temp.pTask, temp.Period, temp.Period);
			//SCH_tasks_G[i].RunMe = temp.RunMe;
		}
	}
	//SCH_Go_To_Sleep();
}

unsigned char SCH_Delete_Task(uint32_t TASK_INDEX)
{
	unsigned char Index = 0;
	for (Index = TASK_INDEX+1; Index < SCH_MAX_TASKS; Index++)
	{
		SCH_tasks_G[Index - 1] = SCH_tasks_G[Index];
	}
	SCH_tasks_G[SCH_MAX_TASKS-1].pTask = 0x000;
	SCH_tasks_G[SCH_MAX_TASKS-1].Delay = 2147483647;
	SCH_tasks_G[SCH_MAX_TASKS-1].Period = 0;
	SCH_tasks_G[SCH_MAX_TASKS-1].RunMe = 0;
	//HAL_GPIO_TogglePin(TEST_LED_GPIO_Port, TEST_LED_Pin);
	return Index;
}

void SCH_Go_To_Sleep(void)
{
	HAL_SuspendTick();
	HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);
	HAL_ResumeTick();
}

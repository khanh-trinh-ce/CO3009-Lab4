/*
 * tasks.h
 *
 *  Created on: Nov 21, 2021
 *      Author: khanh
 */

#ifndef INC_TASKS_H_
#define INC_TASKS_H_

void blink_yellow_led(void);
void blink_purple_led(void);
void blink_blue_led(void);
void blink_green_led(void);
void blink_red_led(void);

#endif /* INC_TASKS_H_ */
